# AI_AURELIO

Aplicación Android basada en OfflineGPT de shauryag2002, commit
11d34c5012673e817703e3b6416c28f9036b5602. Conserva la licencia MIT
incluida y la interfaz de conversación original. Identidad independiente:
com.aiaurelio.office, versión 1.0.0 (100), Android 10 o posterior, ARM64.

## Uso

Solo un mensaje que empieza con Word, Excel, PowerPoint, power point, PDF
o TXT activa la herramienta correspondiente. Las palabras en medio del
mensaje no activan ofimática. Elegir una herramienta inserta su nombre al
inicio del campo; no deja un modo persistente para el siguiente mensaje.
La conversación normal conserva su historial. Español es el idioma por
defecto; se respeta otro idioma solicitado.

El modelo Qwen3-8B Q4_K_M (5.027.783.488 bytes) se descarga con
DownloadManager en Download/AI_AURELIO/Modelos. Se puede seleccionar
una copia existente con el selector Android. Se verifica su SHA-256 y se
carga mediante llama.rn dentro del proceso de la aplicación. No usa Termux
ni un servidor HTTP externo. La carga efectiva depende del dispositivo;
no se ha medido el rendimiento de esta compilación en el teléfono.

El modelo genera contenido CSV. El agente interpreta campos, verifica
estructura, filas, columnas, fórmulas y requisitos explícitos, realiza
correcciones inequívocas y devuelve errores de contenido al modelo para
reparación. Solo publica CSV y documento después de la construcción.
Los trabajos interrumpidos conservan su borrador y permiten reanudar.
Después de tres repeticiones del mismo error se conserva el trabajo para
reanudarlo, evitando un ciclo sin progreso.

Los documentos finales se guardan en Download/AI_AURELIO y aparecen
con botones Abrir documento y Abrir CSV. XLSX contiene fórmulas reales;
DOCX, PPTX, PDF y TXT contienen el texto generado. El PDF utiliza fuentes
del sistema y paginación; sus tablas se representan como filas de texto.

## Estado de esta entrega

El código está preparado. NO se ha generado un APK nuevo en esta sesión.
La política de red del entorno bloqueó Maven Central durante la compilación.
El intento sin conexión se detuvo por falta de
org.jetbrains.kotlin:kotlin-util-klib:1.9.24 en la caché.
Prueba mínima posterior: TypeScript sin errores; detección de herramientas
solo al principio; CSV con comillas y saltos; corrección de una hoja de
16 filas y 4 columnas con constante, rango aleatorio, multiplicaciones y
total; reapertura de XLSX con fórmulas y valores; creación mínima de DOCX,
TXT y PPTX. El conjunto terminó correctamente en unos 0,5 segundos.
No se comprobó la aplicación en un teléfono ni el PDF nativo ni la inferencia.
La solicitud formal de acceso a las dependencias también fue rechazada por
la política de autorización de este entorno. El proyecto incluye un flujo
GitHub Actions para compilar en un entorno autorizado por el propietario.

## Compilación

En un equipo con Node 22, Python 3.12+, Java 21 y Java 17, Android SDK 36,
Build Tools 36.0.0/35.0.0, NDK 27.1.12297006 y CMake 3.22.1, ejecutar
scripts/compilar.py con Python. Configurar ANDROID_HOME. El script instala
las dependencias fijadas por package-lock, verifica las bibliotecas nativas,
genera una firma propia si falta y compila dist/AI_AURELIO.apk.
No ejecutar prebuild --clean: el puente Android está incluido en android/.
El modelo de 5 GB se descarga desde la app; no forma parte del APK.

Alternativa: importar el proyecto en un repositorio propio y ejecutar
Actions → Compilar AI_AURELIO. Esta tarea no ejecuta pruebas funcionales.
Para mantener la misma firma en futuras compilaciones, configurar los
secretos AI_AURELIO_KEYSTORE_B64 y AI_AURELIO_KEY_PASSWORD con la
clave privada conservada. No publicar la clave en el repositorio.

## Fuentes y componentes

- OfflineGPT: https://github.com/shauryag2002/OfflineGPT
- Expo 56: https://docs.expo.dev/versions/v56.0.0/
- llama.rn: https://github.com/mybigday/llama.rn
- Modelo: https://huggingface.co/Qwen/Qwen3-8B-GGUF
- CSV RFC 4180: https://www.rfc-editor.org/rfc/rfc4180
- OOXML ECMA-376: https://ecma-international.org/publications-and-standards/standards/ecma-376/
- Exportadores: xlsx (SheetJS), docx, pptxgenjs, fast-formula-parser y Android PdfDocument.

Las guías de formato se incluyen en src/office/core.ts y se tokenizan
con el tokenizador del modelo al preparar cada solicitud. Son guías de
estructura; no incluyen filas, nombres ni documentos prefabricados.
