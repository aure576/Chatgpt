package com.aiaurelio.office;
import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.*;
import com.facebook.react.uimanager.ViewManager;
import java.util.*;
public class AurelioFilesPackage implements ReactPackage {
 public List<NativeModule> createNativeModules(ReactApplicationContext c){return Collections.singletonList(new AurelioFilesModule(c));}
 public List<ViewManager> createViewManagers(ReactApplicationContext c){return Collections.emptyList();}
}
