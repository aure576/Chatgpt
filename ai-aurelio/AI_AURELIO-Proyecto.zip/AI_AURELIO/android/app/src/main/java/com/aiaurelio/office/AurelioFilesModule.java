package com.aiaurelio.office;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.*;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.Base64;
import com.facebook.react.bridge.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;

public class AurelioFilesModule extends ReactContextBaseJavaModule {
  private static final String URL="https://huggingface.co/Qwen/Qwen3-8B-GGUF/resolve/main/Qwen3-8B-Q4_K_M.gguf";
  private static final String SHA="d98cdcbd03e17ce47681435b5150e34c1417f50b5c0019dd560e4882c5745785";
  private static final long SIZE=5027783488L;
  private final ReactApplicationContext ctx;
  private final SharedPreferences prefs;
  private final ExecutorService io=Executors.newSingleThreadExecutor();
  private ParcelFileDescriptor modelFd;
  private Promise picker;
  private volatile long verifiedBytes=0;
  private volatile boolean verifying=false;
  private volatile String verificationError="";
  AurelioFilesModule(ReactApplicationContext c){
    super(c);ctx=c;prefs=c.getSharedPreferences("aurelio_files",Context.MODE_PRIVATE);
    c.addActivityEventListener(new BaseActivityEventListener(){
      @Override public void onActivityResult(Activity a,int request,int result,Intent data){
        if(request!=731||picker==null)return;Promise promise=picker;picker=null;
        if(result!=Activity.RESULT_OK||data==null||data.getData()==null){promise.reject("CANCELADO","Selección cancelada.");return;}
        try{
          Uri uri=data.getData();ctx.getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
          long id=prefs.getLong("download",-1);if(id!=-1)manager().remove(id);
          prefs.edit().putString("model",uri.toString()).remove("download").remove("verified_uri").apply();verificationError="";promise.resolve(null);
        }catch(Exception e){fail(promise,e);}
      }
    });
  }
  @Override public String getName(){return "AurelioFiles";}
  private DownloadManager manager(){return (DownloadManager)ctx.getSystemService(Context.DOWNLOAD_SERVICE);}
  private void fail(Promise p,Exception e){p.reject("AURELIO",e.getMessage()==null?e.toString():e.getMessage(),e);}
  @ReactMethod public void modelState(Promise p){
    try{
      WritableMap s=Arguments.createMap();long bytes=0,total=SIZE;String stage="missing",message="Qwen3-8B · modelo de aproximadamente 5 GB";
      if(verifying){stage="verifying";bytes=verifiedBytes;message="Verificando la integridad del modelo…";}
      else if(!verificationError.isEmpty()){stage="error";message=verificationError;}
      else if(!prefs.getString("model","").isEmpty()){stage="downloaded";bytes=SIZE;message="Modelo descargado. Preparando el motor…";}
      else {
        long id=prefs.getLong("download",-1);
        if(id!=-1){try(Cursor c=manager().query(new DownloadManager.Query().setFilterById(id))){
          if(c.moveToFirst()){
            bytes=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));long t=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));if(t>0)total=t;
            int state=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            if(state==DownloadManager.STATUS_SUCCESSFUL){Uri u=manager().getUriForDownloadedFile(id);if(u==null)throw new IOException("La descarga finalizó pero Android no entrega el archivo.");prefs.edit().putString("model",u.toString()).apply();stage="downloaded";message="Descarga completa. Verificando…";}
            else if(state==DownloadManager.STATUS_FAILED){stage="error";message="Descarga fallida (Android "+c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))+"). Pulsa Reintentar.";}
            else if(state==DownloadManager.STATUS_PAUSED){stage="paused";message="Descarga en pausa; Android la reanudará cuando haya conexión y espacio.";}
            else {stage="downloading";message="Descargando en Download/AI_AURELIO/Modelos";}
          }else{prefs.edit().remove("download").apply();}
        }}
      }
      s.putString("stage",stage);s.putString("message",message);s.putDouble("bytes",bytes);s.putDouble("total",total);s.putDouble("progress",total>0?(double)bytes/total:0);p.resolve(s);
    }catch(Exception e){fail(p,e);}
  }
  @ReactMethod public void startDownload(Promise p){
    try{
      if(!prefs.getString("model","").isEmpty()&&verificationError.isEmpty()){p.resolve(null);return;}
      long old=prefs.getLong("download",-1);
      if(old!=-1){try(Cursor c=manager().query(new DownloadManager.Query().setFilterById(old))){if(c.moveToFirst()&&c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))!=DownloadManager.STATUS_FAILED&&verificationError.isEmpty()){p.resolve(null);return;}}manager().remove(old);}
      verificationError="";
      DownloadManager.Request r=new DownloadManager.Request(Uri.parse(URL));
      r.setTitle("AI_AURELIO · Qwen3-8B").setDescription("Modelo local · aproximadamente 5 GB").setAllowedOverMetered(true).setAllowedOverRoaming(false).setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
      r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"AI_AURELIO/Modelos/Qwen3-8B-Q4_K_M-"+System.currentTimeMillis()+".gguf");
      long id=manager().enqueue(r);prefs.edit().putLong("download",id).remove("model").remove("verified_uri").apply();p.resolve(null);
    }catch(Exception e){fail(p,e);}
  }
  @ReactMethod public void selectModel(Promise p){
    Activity a=ctx.getCurrentActivity();if(a==null){p.reject("ACTIVITY","Abre la aplicación para seleccionar el modelo.");return;}
    if(picker!=null){p.reject("PICKER","El selector ya está abierto.");return;}picker=p;
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
    try{a.startActivityForResult(i,731);}catch(Exception e){picker=null;fail(p,e);}
  }
  @ReactMethod public void openModel(Promise p){io.execute(()->{
    try{
      if(modelFd!=null){p.resolve("/proc/self/fd/"+modelFd.getFd());return;}
      String value=prefs.getString("model","");if(value.isEmpty())throw new IOException("Todavía no hay un modelo descargado.");Uri u=Uri.parse(value);
      ParcelFileDescriptor descriptor=ctx.getContentResolver().openFileDescriptor(u,"r");if(descriptor==null)throw new IOException("No se puede leer el modelo.");
      try{
        long size=descriptor.getStatSize();if(size!=SIZE)throw new IOException("Selecciona Qwen3-8B-Q4_K_M completo: se necesitan "+SIZE+" bytes; hay "+size+".");
        if(!value.equals(prefs.getString("verified_uri",""))){
          verifying=true;verifiedBytes=0;MessageDigest digest=MessageDigest.getInstance("SHA-256");
          try(InputStream in=ctx.getContentResolver().openInputStream(u)){if(in==null)throw new IOException("El modelo no es legible.");byte[] b=new byte[4*1024*1024];int n;while((n=in.read(b))!=-1){digest.update(b,0,n);verifiedBytes+=n;}}
          StringBuilder hex=new StringBuilder();for(byte b:digest.digest())hex.append(String.format(Locale.ROOT,"%02x",b&255));
          if(!SHA.equals(hex.toString()))throw new IOException("El modelo no supera la verificación SHA-256. Reintenta o selecciona la copia completa.");
          prefs.edit().putString("verified_uri",value).apply();
        }
        modelFd=descriptor;verificationError="";p.resolve("/proc/self/fd/"+descriptor.getFd());
      }catch(Exception e){descriptor.close();throw e;}
    }catch(Exception e){verificationError=e.getMessage();fail(p,e);}finally{verifying=false;}
  });}
  @ReactMethod public void closeModel(Promise p){io.execute(()->{try{if(modelFd!=null)modelFd.close();modelFd=null;p.resolve(null);}catch(Exception e){fail(p,e);}});}
  private File draft(){return new File(ctx.getFilesDir(),"office-pending.json");}
  @ReactMethod public void saveDraft(String data,Promise p){io.execute(()->{try{File temp=new File(ctx.getFilesDir(),"office-pending.tmp");try(FileOutputStream f=new FileOutputStream(temp)){f.write(data.getBytes(StandardCharsets.UTF_8));f.getFD().sync();}Files.move(temp.toPath(),draft().toPath(),StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);p.resolve(null);}catch(Exception e){fail(p,e);}});}
  @ReactMethod public void readDraft(Promise p){io.execute(()->{try{p.resolve(draft().exists()?new String(Files.readAllBytes(draft().toPath()),StandardCharsets.UTF_8):"");}catch(Exception e){fail(p,e);}});}
  @ReactMethod public void clearDraft(Promise p){io.execute(()->{try{Files.deleteIfExists(draft().toPath());p.resolve(null);}catch(Exception e){fail(p,e);}});}
  private Uri create(String name,String mime)throws IOException{ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,mime);v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/AI_AURELIO");v.put(MediaStore.Downloads.IS_PENDING,1);Uri u=ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new IOException("Android no pudo crear el archivo en Download.");return u;}
  private void write(Uri u,byte[] b)throws IOException{try(OutputStream out=ctx.getContentResolver().openOutputStream(u,"w")){if(out==null)throw new IOException("No se pudo abrir el archivo de salida.");out.write(b);out.flush();}}
  @ReactMethod public void publish(String name,String ext,String mime,String csv,String data,Promise p){io.execute(()->{
    Uri cu=null,du=null;try{
      String safe=name.replaceAll("[^a-zA-Z0-9_-]","_");if(!ext.matches("xlsx|docx|pptx|pdf|txt"))throw new IOException("Formato no permitido.");
      cu=create(safe+".csv","text/csv");du=create(safe+"."+ext,mime);write(cu,csv.getBytes(StandardCharsets.UTF_8));write(du,Base64.decode(data,Base64.DEFAULT));
      ContentValues visible=new ContentValues();visible.put(MediaStore.Downloads.IS_PENDING,0);
      if(ctx.getContentResolver().update(cu,visible,null,null)!=1||ctx.getContentResolver().update(du,visible,null,null)!=1)throw new IOException("No se pudo publicar el documento completo.");
      WritableMap result=Arguments.createMap();result.putString("uri",du.toString());result.putString("csvUri",cu.toString());result.putString("name",safe+"."+ext);result.putString("mime",mime);result.putString("path","Download/AI_AURELIO/"+safe+"."+ext);p.resolve(result);
    }catch(Exception e){if(cu!=null)ctx.getContentResolver().delete(cu,null,null);if(du!=null)ctx.getContentResolver().delete(du,null,null);fail(p,e);}
  });}
  @ReactMethod public void openDocument(String uri,String mime,Promise p){try{Intent i=new Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri),mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);ctx.startActivity(i);p.resolve(null);}catch(Exception e){p.reject("VIEW","El archivo está guardado en Download/AI_AURELIO. Instala un visor compatible para abrirlo.");}}
  @ReactMethod public void pdf(String json,Promise p){io.execute(()->{
    PdfDocument doc=new PdfDocument();try{
      JSONArray blocks=new JSONArray(json);int number=1,y=48;PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,number).create());
      for(int i=0;i<blocks.length();i++){
        JSONArray b=blocks.getJSONArray(i);String kind=b.getString(0),text=b.getString(1);
        if(kind.equals("salto")){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++number).create());y=48;continue;}
        if(kind.equals("tabla")){JSONArray table=new JSONArray(text);StringBuilder t=new StringBuilder();for(int r=0;r<table.length();r++){JSONArray row=table.getJSONArray(r);for(int c=0;c<row.length();c++){if(c>0)t.append("  |  ");t.append(row.get(c));}t.append('\n');}text=t.toString();}
        if(kind.equals("vineta"))text="• "+text;
        TextPaint paint=new TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG);paint.setColor(Color.BLACK);paint.setTextSize(kind.equals("titulo")?22:kind.equals("subtitulo")?16:12);
        StaticLayout layout=StaticLayout.Builder.obtain(text,0,text.length(),paint,499).setAlignment(Layout.Alignment.ALIGN_NORMAL).setIncludePad(false).setLineSpacing(3,1).build();
        for(int line=0;line<layout.getLineCount();){
          int start=line,top=layout.getLineTop(start);while(line<layout.getLineCount()&&y+layout.getLineBottom(line)-top<=792)line++;
          if(line==start){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++number).create());y=48;continue;}
          int h=layout.getLineBottom(line-1)-top;Canvas canvas=page.getCanvas();canvas.save();canvas.clipRect(48,y,547,y+h);canvas.translate(48,y-top);layout.draw(canvas);canvas.restore();y+=h;
          if(line<layout.getLineCount()){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++number).create());y=48;}
        }y+=12;
      }
      doc.finishPage(page);ByteArrayOutputStream out=new ByteArrayOutputStream();doc.writeTo(out);p.resolve(Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP));
    }catch(Exception e){fail(p,e);}finally{doc.close();}
  });}
}
