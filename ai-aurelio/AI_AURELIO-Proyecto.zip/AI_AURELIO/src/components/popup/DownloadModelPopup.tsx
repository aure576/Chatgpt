import GPTService from "@/services/GPTService";
import { DownloadModelPopupProps } from "@/types/DownloadModelPopup";
import {
  BasicAlertDialog,
  Button,
  Column,
  Host,
  LinearProgressIndicator,
  Surface,
  Text,
} from "@expo/ui/jetpack-compose";
import {
  padding,
  width,
  wrapContentHeight,
  wrapContentWidth,
} from "@expo/ui/jetpack-compose/modifiers";
import React, { useState } from "react";

const DEFAULT_MODEL_URL =
  process.env.EXPO_PUBLIC_MODEL_URL ||
  "https://huggingface.co/Qwen/Qwen3-8B-GGUF/resolve/main/Qwen3-8B-Q4_K_M.gguf";

const DownloadModelPopup: React.FC<DownloadModelPopupProps> = ({
  visible,
  modelUrl,
  onDownloaded,
}) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [statusMessage, setStatusMessage] = useState("Descargando modelo…");
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  if (!visible) {
    return null;
  }

  const handleDownload = async () => {
    const targetUrl = modelUrl || DEFAULT_MODEL_URL;
    setError(null);
    setIsDownloading(true);
    setProgress(0);
    setStatusMessage("Descargando archivo…");

    try {
      const gptService = GPTService.getInstance();
      await gptService.downloadModelToMobile(targetUrl, true, (data) => {
        if (data.totalBytes > 0) {
          setProgress(data.bytesWritten / data.totalBytes);
          setStatusMessage("Descargando modelo…");
        }
      });

      setStatusMessage("Cargando motor…");
      setProgress(1);

      // Wait for parent component to complete LLM initialization before closing modal
      await onDownloaded();
    } catch (err) {
      console.error("Error downloading or initializing model:", err);
      setError(
        "No se pudo descargar o cargar el modelo. Reintenta.",
      );
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <Host matchContents>
      <BasicAlertDialog
        properties={{
          dismissOnBackPress: false,
          dismissOnClickOutside: false,
        }}
      >
        <Surface
          tonalElevation={6}
          modifiers={[width(320), wrapContentHeight(), wrapContentWidth()]}
        >
          <Column
            verticalArrangement={{ spacedBy: 12 }}
            modifiers={[padding(20, 20, 20, 20)]}
          >
            <Text style={{ typography: "titleLarge" }}>
              Descargar modelo
            </Text>

            <Text>
              Qwen3-8B se guarda en Download/AI_AURELIO/Modelos y funciona dentro de la aplicación.
            </Text>

            {isDownloading && (
              <Column verticalArrangement={{ spacedBy: 4 }}>
                <LinearProgressIndicator
                  progress={progress}
                  modifiers={[width(280)]}
                />
                <Text>{statusMessage} ({Math.round(progress * 100)}%)</Text>
              </Column>
            )}

            {error && <Text color="red">{error}</Text>}

            <Button onClick={handleDownload} enabled={!isDownloading}>
              <Text>{isDownloading ? "Procesando…" : "Descargar modelo"}</Text>
            </Button>
          </Column>
        </Surface>
      </BasicAlertDialog>
    </Host>
  );
};

export default DownloadModelPopup;
