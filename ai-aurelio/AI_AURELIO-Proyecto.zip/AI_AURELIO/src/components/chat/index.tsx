import ChatStorageService from '@/services/ChatStorageService';
import Runtime from '@/services/LlamaRuntimeService';
import { useEffect, useRef, useState } from 'react';
import { Alert, FlatList, Modal, Platform, Pressable, View } from 'react-native';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { SafeAreaView } from 'react-native-safe-area-context';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import { AppText } from '../common';
import { ChatHeader } from './ChatHeader';
import { ChatInputBox } from './ChatInputBox';
import { ChatMessage, ChatMessageItem } from './ChatMessageItem';
import { Agent, Draft } from '../../office/agent';
import { Files, ModelState } from '../../office/native';
import { TOOLS, prepare, routeInput } from '../../office/core';
import { Colors } from '../../constants/theme';
import styles from './style';

const welcome:ChatMessage={id:'welcome',role:'assistant',content:'Hola, soy AI_AURELIO. Puedes conversar normalmente. Para crear un documento, empieza con Word, Excel, PowerPoint, PDF o TXT, o abre Herramientas.'};
export default function ChatScreen(){
 const [input,setInput]=useState(''),[messages,setMessages]=useState<ChatMessage[]>([welcome]);
 const [busy,setBusy]=useState(false),[ready,setReady]=useState(false),[loading,setLoading]=useState(false);
 const [state,setState]=useState<ModelState>({stage:'missing',bytes:0,total:5027783488,progress:0,message:'Preparando modelo local…'});
 const [status,setStatus]=useState(''),[hint,setHint]=useState(''),[menu,setMenu]=useState(false),[pending,setPending]=useState<Draft|null>(null);
 const [reload,setReload]=useState(0);
 const list=useRef<FlatList>(null), running=useRef(false), cancelled=useRef(false);
 const runtime=Runtime.getInstance(), storage=ChatStorageService.getInstance();
 useEffect(()=>{let active=true;storage.getChatMessages().then(m=>{if(active&&m.length)setMessages(m);});Files.readDraft().then(s=>{if(active&&s)setPending(JSON.parse(s));}).catch(e=>setStatus(String(e)));return()=>{active=false;runtime.stopCompletion().catch(()=>{});};},[]);
 useEffect(()=>{
  let active=true,polling=false,failed=false;
  const poll=async()=>{
   if(polling||!active||failed)return;polling=true;
   try{
    if(runtime.ready){setReady(true);setLoading(false);return;}
    const s=await Files.modelState();if(!active)return;setState(s);
    if(s.stage==='missing')await Files.startDownload();
    else if(s.stage==='downloaded'){
     setLoading(true);await activateKeepAwakeAsync('aurelio-model');
     // Verification progress remains observable while the native I/O worker hashes the model.
     const monitor=setInterval(()=>{Files.modelState().then(v=>{if(active&&v.stage==='verifying')setState(v);}).catch(()=>{});},1200);
     let path;try{path=await Files.openModel();}finally{clearInterval(monitor);}
     if(!active)return;
     setState({...s,stage:'loading',progress:0,message:'Cargando Qwen3-8B en memoria…'});
     await runtime.initializeLlamaRuntime(path,n=>{if(active)setState({...s,stage:'loading',progress:n>1?n/100:n,message:'Cargando motor local…'});});
     if(active){setReady(true);setLoading(false);setState({...s,stage:'ready',progress:1,message:'Modelo verificado · motor '+runtime.backend+' listo'});}
    }
   }catch(e){failed=true;if(active){setLoading(false);setState(s=>({...s,stage:'error',message:e instanceof Error?e.message:String(e)}));}}
   finally{polling=false;deactivateKeepAwake('aurelio-model').catch(()=>{});}
  };
  poll();const timer=setInterval(poll,1500);return()=>{active=false;clearInterval(timer);deactivateKeepAwake('aurelio-model').catch(()=>{});};
 },[reload]);
 useEffect(()=>{const timer=setTimeout(()=>{const f=routeInput(input);setHint(f?prepare(f,input).summary:'');},250);return()=>clearTimeout(timer);},[input]);
 const send=async(resume?:Draft)=>{
  const text=resume?.request||input.trim();if(!text||!ready||running.current)return;
  const format=resume?.format||routeInput(text);
  if(format&&pending&&!resume){Alert.alert('Hay un trabajo guardado','Pulsa Reanudar o Descartar antes de empezar otro documento.');return;}
  running.current=true;cancelled.current=false;setBusy(true);setInput('');
  const id=Date.now().toString(),user:ChatMessage={id:id+'u',role:'user',content:text,mode:format||undefined};
  const base=[...messages,user];setMessages([...base,{id,role:'assistant',content:'',mode:format||undefined}]);
  const update=(value:string)=>setMessages([...base,{id,role:'assistant',content:value,mode:format||undefined}]);
  await storage.saveChatMessages(base);await activateKeepAwakeAsync('aurelio-work').catch(()=>{});
  const start=Date.now();let chars=0;
  const elapsed=setInterval(()=>{if(chars)setStatus(`Modelo: ${chars} caracteres · ${Math.floor((Date.now()-start)/1000)} s`);},1000);
  try{
   let final:ChatMessage;
   if(format){
    const result=await Agent.run(format,text,s=>{chars=0;setStatus(s);},value=>{chars=value.length;update(value);},resume);
    final={id,role:'assistant',content:result.text,artifact:result.artifact,mode:format};setPending(null);
   }else{
    setStatus('Modelo: respondiendo…');
    const response=await runtime.generate([{role:'system',content:'Eres AI_AURELIO, un asistente local. Responde en español salvo que el usuario solicite otro idioma.'},...base.filter(m=>!m.mode&&m.id!=='welcome').map(m=>({role:m.role,content:m.content}))],value=>{chars=value.length;update(value);});
    final={id,role:'assistant',content:response};setStatus('Respuesta terminada.');
   }
   const all=[...base,final];setMessages(all);await storage.saveChatMessages(all);
  }catch(e){
   const detail=e instanceof Error?e.message:String(e);setStatus(detail);
   const raw=await Files.readDraft().catch(()=>''),draft=raw?JSON.parse(raw) as Draft:null;setPending(draft);
   const final=[...base,{id,role:'assistant' as const,content:detail,mode:format||undefined}];setMessages(final);await storage.saveChatMessages(final);
  }finally{clearInterval(elapsed);running.current=false;setBusy(false);deactivateKeepAwake('aurelio-work').catch(()=>{});}
 };
 const changeModel=async()=>{try{await runtime.unloadModel();await Files.closeModel();setReady(false);await Files.selectModel();setReload(n=>n+1);}catch(e){setStatus(e instanceof Error?e.message:String(e));setReload(n=>n+1);}};
 const button=(label:string,action:()=>void,disabled=false)=><Pressable disabled={disabled} onPress={action} style={{padding:10,borderRadius:8,backgroundColor:Colors.backgroundSelected,opacity:disabled?.45:1}}><AppText>{label}</AppText></Pressable>;
 return <SafeAreaView style={styles.container} edges={['top','left','right','bottom']}>
  <ChatHeader title="AI_AURELIO" subtitle={ready?'Modelo local listo':'Preparando modelo…'} onTools={()=>setMenu(true)} clearHistory={async()=>{if(busy)return;setMessages([welcome]);await storage.clearChatMessages();}} />
  {!ready&&<View style={{padding:12,gap:6,backgroundColor:Colors.backgroundElement}}>
   <AppText>{state.message}</AppText>
   <View style={{height:5,backgroundColor:Colors.backgroundSelected}}><View style={{height:5,width:`${Math.min(100,Math.max(0,state.progress*100))}%`,backgroundColor:'#88D498'}}/></View>
   <AppText variant="caption">{state.stage==='loading'?`${Math.round(state.progress*100)}% cargado`:`${(state.bytes/1e9).toFixed(2)} / ${(state.total/1e9).toFixed(2)} GB`} · Download/AI_AURELIO/Modelos</AppText>
   <View style={{flexDirection:'row',gap:8}}>{button('Usar modelo descargado',changeModel,loading||busy)}{state.stage==='error'&&button('Reintentar',()=>{Files.startDownload().then(()=>setReload(n=>n+1)).catch(e=>setStatus(String(e)));},busy)}</View>
  </View>}
  <KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==='ios'?'padding':'height'} keyboardVerticalOffset={0}>
   <FlatList ref={list} data={messages} keyExtractor={m=>m.id} style={{flex:1}} renderItem={({item})=><ChatMessageItem message={item}/>} contentContainerStyle={styles.listContent} onContentSizeChange={()=>list.current?.scrollToEnd({animated:false})}/>
   {!!status&&<AppText variant="caption" style={{paddingHorizontal:12,paddingVertical:5}}>{status}</AppText>}
   {pending&&!busy&&<View style={{padding:10,gap:6}}><AppText variant="caption">Trabajo guardado: {pending.request}</AppText><View style={{flexDirection:'row',gap:8}}>{button('Reanudar',()=>send(pending),!ready)}{button('Descartar',()=>{Alert.alert('Descartar borrador','¿Descartar solo este trabajo incompleto?',[{text:'Conservar'},{text:'Descartar',onPress:()=>{Files.clearDraft().then(()=>setPending(null));}}]);})}</View></View>}
   {busy&&<View style={{paddingHorizontal:12}}>{button('Detener y conservar',()=>{cancelled.current=true;runtime.stopCompletion().catch(e=>setStatus(String(e)));})}</View>}
   {!!hint&&<AppText variant="caption" style={{paddingHorizontal:12}}>{hint}</AppText>}
   <ChatInputBox value={input} onChangeText={setInput} onSend={()=>send()} isGenerating={busy} isModelLoaded={ready}/>
  </KeyboardAvoidingView>
  <Modal visible={menu} transparent animationType="fade" onRequestClose={()=>setMenu(false)}><View style={{flex:1,justifyContent:'center',padding:28,backgroundColor:'#0009'}}><View style={{backgroundColor:Colors.background,padding:20,borderRadius:16,gap:12}}><AppText variant="subtitle">Herramientas</AppText>{TOOLS.map(t=><View key={t.id}>{button(t.name+' · .'+t.ext,()=>{setInput(t.name+' ');setMenu(false);},busy)}</View>)}{button('Conversación normal',()=>{setInput('');setMenu(false);},busy)}{button('Cerrar',()=>setMenu(false))}</View></View></Modal>
 </SafeAreaView>;
}
