import { Colors } from "@/constants/theme";
import { useRouter } from "expo-router";
import React from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import { AppText } from "../common";

interface ChatHeaderProps {
  title?: string;
  subtitle?: string;
  showBackButton?: boolean;
  clearHistory: () => void;
  onTools?: () => void;
}

/**
 * ChatHeader component displayed at the top of the Chat page.
 */
export const ChatHeader: React.FC<ChatHeaderProps> = ({
  title = "AI_AURELIO",
  subtitle = "Local AI Engine",
  showBackButton = false,
  clearHistory,
  onTools,
}) => {
  const router = useRouter();

  return (
    <View style={styles.container}>
      {showBackButton ? (
        <TouchableOpacity
          activeOpacity={0.7}
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <AppText style={styles.backText}>← Back</AppText>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity onPress={onTools} style={styles.backButton}><AppText style={styles.backText}>Herramientas</AppText></TouchableOpacity>
      )}

      <View style={styles.titleContainer}>
        <AppText variant="subtitle">{title}</AppText>
        <AppText variant="caption">{subtitle}</AppText>
      </View>

      <TouchableOpacity
        activeOpacity={0.7}
        style={styles.clearButton}
        onPress={clearHistory}
      >
        <AppText style={styles.clearText}>Limpiar</AppText>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.backgroundElement,
    backgroundColor: Colors.background,
  },
  backButton: {
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
    backgroundColor: Colors.backgroundElement,
  },
  backText: {
    fontSize: 13,
    fontWeight: "500",
  },
  placeholder: {
    width: 50,
  },
  titleContainer: {
    alignItems: "center",
  },
  clearButton: {
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
    backgroundColor: Colors.backgroundElement,
  },
  clearText: {
    fontSize: 13,
    fontWeight: "500",
  },
});
