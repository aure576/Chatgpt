import React from "react";
import { Files, Artifact } from "../../office/native";
import { Format } from "../../office/core";
import { View, StyleSheet, Pressable, Alert } from "react-native";
import { Colors } from "@/constants/theme";
import { AppText } from "../common";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  artifact?: Artifact;
  mode?: Format;
}

interface ChatMessageItemProps {
  message: ChatMessage;
}

/**
 * ChatMessageItem component to render message bubbles.
 * User messages align to the right, Assistant messages align to the left.
 */
export const ChatMessageItem: React.FC<ChatMessageItemProps> = ({ message }) => {
  const isUser = message.role === "user";

  return (
    <View
      style={[
        styles.row,
        isUser ? styles.userRow : styles.assistantRow,
      ]}
    >
      <View
        style={[
          styles.bubble,
          isUser ? styles.userBubble : styles.assistantBubble,
        ]}
      >
        <AppText variant="caption" style={styles.roleText}>
          {isUser ? "Tú" : "AI_AURELIO"}
        </AppText>
        <AppText selectable style={styles.messageText}>{message.content}</AppText>
        {message.artifact && <View style={{gap:8,marginTop:12}}>
          <Pressable onPress={()=>Files.openDocument(message.artifact!.uri,message.artifact!.mime).catch(e=>Alert.alert('Documento',String(e)))}><AppText>Abrir documento ↗</AppText></Pressable>
          <Pressable onPress={()=>Files.openDocument(message.artifact!.csvUri,'text/csv').catch(e=>Alert.alert('CSV',String(e)))}><AppText>Abrir CSV ↗</AppText></Pressable>
          <AppText variant="caption">{message.artifact.path}</AppText>
        </View>}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  row: {
    marginVertical: 6,
    flexDirection: "row",
  },
  userRow: {
    justifyContent: "flex-end",
  },
  assistantRow: {
    justifyContent: "flex-start",
  },
  bubble: {
    maxWidth: "80%",
    padding: 12,
    borderRadius: 14,
  },
  userBubble: {
    backgroundColor: Colors.backgroundSelected,
    borderBottomRightRadius: 2,
  },
  assistantBubble: {
    backgroundColor: Colors.backgroundElement,
    borderBottomLeftRadius: 2,
  },
  roleText: {
    marginBottom: 4,
    fontWeight: "600",
    color: Colors.textSecondary,
  },
  messageText: {
    lineHeight: 20,
  },
});
