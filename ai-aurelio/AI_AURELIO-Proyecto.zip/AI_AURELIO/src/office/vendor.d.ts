declare module 'fast-formula-parser' { const FormulaParser:any;export default FormulaParser; }
declare module '*.css';
