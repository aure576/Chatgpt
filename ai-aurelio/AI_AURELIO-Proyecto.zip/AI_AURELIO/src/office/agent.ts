import Runtime from '../services/LlamaRuntimeService';
import { Format, prepare, validateAndRepair, preview } from './core';
import { buildDocument } from './exporters';
import { Files } from './native';
export interface Draft {id:string;format:Format;request:string;csv:string;phase:'modelo'|'agente';errors:string[]}
class OfficeAgent {
  private busy=false;
  async run(format:Format,request:string,notify:(status:string)=>void,stream:(text:string)=>void,resume?:Draft) {
    if(this.busy)throw Error('El agente ya está trabajando.');this.busy=true;
    const draft:Draft=resume||{id:Date.now().toString(),format,request,csv:'',phase:'modelo',errors:[]};
    const plan=prepare(draft.format,draft.request), runtime=Runtime.getInstance();
    const save=()=>Files.saveDraft(JSON.stringify(draft));
    const attempts:Record<string,number>={};
    try{
      await save();
      for(;;){
        if(draft.phase==='modelo'){
          notify('Modelo: creando el contenido…');
          const correction=draft.errors.length?'\nCorrige el CSV según la orden original. Errores del agente: '+draft.errors.slice(-5).join('; '):'';
          draft.csv=await runtime.generate([{role:'system',content:plan.system},{role:'user',content:draft.request+correction}],stream,plan,draft.csv,async csv=>{draft.csv=csv;await save();});
          draft.phase='agente';await save();
        }
        notify('Agente: verificando y construyendo el documento…');
        let checked,document;
        try{
          checked=validateAndRepair(draft.csv,plan);draft.csv=checked.csv;await save();
          if(checked.repairs.length)notify(`Agente: ${checked.repairs.length} correcciones aplicadas; verificando…`);
          document=await buildDocument(checked.rows,draft.format);
        }catch(e){
          const error=e instanceof Error?e.message:String(e);draft.errors.push(error);
          attempts[error]=(attempts[error]||0)+1;
          if(attempts[error]>=3){await save();throw Error('El agente conservó el CSV tras repetir el mismo error: '+error+'. Puedes reanudar el trabajo.');}
          notify('Agente: corrigiendo '+error);
          const faulty=draft.csv;draft.phase='modelo';draft.csv='';await save();
          draft.csv=await runtime.generate([{role:'system',content:plan.system},{role:'user',content:draft.request+'\nCorrige este CSV sin cambiar la orden. Errores: '+draft.errors.slice(-5).join('; ')+'\nCSV a corregir:\n'+faulty}],stream,plan,'',async csv=>{draft.csv=csv;await save();});
          draft.phase='agente';await save();continue;
        }
        notify('Agente: guardando en Download/AI_AURELIO…');
        const artifact=await Files.publish('AI_AURELIO_'+draft.id,document.ext,document.mime,draft.csv,document.base64);
        await Files.clearDraft();notify('Documento terminado y guardado.');
        return {artifact,text:preview(checked.rows,draft.format)};
      }
    }finally{this.busy=false;}
  }
}
export const Agent=new OfficeAgent();
