import { Buffer } from 'buffer';
import * as XLSX from 'xlsx';
import { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType } from 'docx';
import PptxGenJS from 'pptxgenjs';
import FormulaParser from 'fast-formula-parser';
import { Format } from './core';
import { Files } from './native';
(globalThis as any).Buffer=Buffer;
export function excelWorkbook(rows:string[][]) {
  const sheet:XLSX.WorkSheet={};const visiting=new Set<string>(),calculated=new Set<string>();
  const numeric=/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/;
  rows.forEach((r,ri)=>r.forEach((v,ci)=>{
    const ref=XLSX.utils.encode_cell({r:ri,c:ci});
    if(ri>0&&v.startsWith('='))sheet[ref]={t:'n',f:v.slice(1),v:0};
    else sheet[ref]=numeric.test(v)&&ri>0?{t:'n',v:Number(v)}:{t:'s',v};
  }));
  const value=(r:number,c:number):any=>{
    const key=XLSX.utils.encode_cell({r:r-1,c:c-1}),cell=sheet[key];
    if(!cell)return 0;if(!cell.f||calculated.has(key))return cell.v;
    if(visiting.has(key))throw Error(`Referencia circular en ${key}.`);
    visiting.add(key);
    const v=parser.parse(cell.f,{row:r,col:c,sheet:'Hoja'});
    if(v&&typeof v==='object'&&'error' in v)throw Error(`Fórmula ${key}: ${v.error}.`);
    if(typeof v!=='number'&&typeof v!=='string'&&typeof v!=='boolean')throw Error(`Resultado de fórmula inválido en ${key}.`);
    if(typeof v==='number'&&!Number.isFinite(v))throw Error(`Cálculo no finito en ${key}.`);
    cell.v=v;cell.t=typeof v==='number'?'n':typeof v==='boolean'?'b':'s';visiting.delete(key);calculated.add(key);return v;
  };
  const parser=new FormulaParser({
    onCell:(ref:any)=>{if(ref.sheet&&ref.sheet!=='Hoja')throw Error('Referencia a hoja externa no disponible.');return value(ref.row,ref.col);},
    onRange:(ref:any)=>{if(ref.sheet&&ref.sheet!=='Hoja')throw Error('Rango externo no disponible.');const data:any[][]=[];for(let r=ref.from.row;r<=ref.to.row;r++){const line:any[]=[];for(let c=ref.from.col;c<=ref.to.col;c++)line.push(value(r,c));data.push(line);}return data;},
  });
  rows.forEach((r,ri)=>r.forEach((_,ci)=>value(ri+1,ci+1)));
  sheet['!ref']=XLSX.utils.encode_range({s:{r:0,c:0},e:{r:rows.length-1,c:rows[0].length-1}});
  sheet['!cols']=rows[0].map((_,c)=>({wch:Math.min(60,Math.max(15,...rows.map(r=>String(r[c]||'').length+2)))}));
  sheet['!autofilter']={ref:XLSX.utils.encode_range({s:{r:0,c:0},e:{r:rows.length-1,c:rows[0].length-1}})};
  const book=XLSX.utils.book_new();XLSX.utils.book_append_sheet(book,sheet,'Hoja');
  book.Workbook={CalcPr:{calcMode:'auto',fullCalcOnLoad:true}} as any;return book;
}
export async function buildDocument(rows:string[][],format:Format) {
  if(format==='excel')return {base64:XLSX.write(excelWorkbook(rows),{bookType:'xlsx',type:'base64'}),ext:'xlsx',mime:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'};
  if(format==='word') {
    const children:(Paragraph|Table)[]=[];
    for(const [kind,text] of rows.slice(1)){
      if(kind==='tabla'){children.push(new Table({width:{size:100,type:WidthType.PERCENTAGE},rows:(JSON.parse(text) as any[][]).map(r=>new TableRow({children:r.map(c=>new TableCell({children:[new Paragraph(String(c))]}))}))}));continue;}
      children.push(new Paragraph({heading:kind==='titulo'?HeadingLevel.TITLE:kind==='subtitulo'?HeadingLevel.HEADING_1:undefined,bullet:kind==='vineta'?{level:0}:undefined,pageBreakBefore:kind==='salto',spacing:{after:180},children:text.split('\n').map((t,i)=>new TextRun({text:t,break:i?1:0}))}));
    }
    const doc=new Document({creator:'AI_AURELIO',styles:{default:{document:{run:{font:'Arial',size:24},paragraph:{spacing:{line:300}}}}},sections:[{properties:{},children}]});
    return {base64:await Packer.toBase64String(doc),ext:'docx',mime:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'};
  }
  if(format==='powerpoint') {
    const pres=new PptxGenJS();pres.layout='LAYOUT_WIDE';pres.author='AI_AURELIO';
    for(const r of rows.slice(1)){const s=pres.addSlide();s.background={color:'F7F9FC'};s.addText(r[1],{x:.6,y:.4,w:12.1,h:1,fontSize:28,bold:true,color:'15304D',fit:'shrink',breakLine:false});s.addText(r[2],{x:.6,y:1.65,w:12.1,h:5.1,fontSize:20,color:'223448',fit:'shrink',valign:'top',margin:0.1});if(r[3])s.addNotes(r[3]);}
    return {base64:await pres.write({outputType:'base64'}) as string,ext:'pptx',mime:'application/vnd.openxmlformats-officedocument.presentationml.presentation'};
  }
  if(format==='pdf')return {base64:await Files.pdf(JSON.stringify(rows.slice(1))),ext:'pdf',mime:'application/pdf'};
  const text=rows.slice(1).map(([k,t])=>k==='salto'?'\f':k==='tabla'?(JSON.parse(t) as any[][]).map(r=>r.join('\t')).join('\n'):t).join('\n\n');
  return {base64:Buffer.from(text,'utf8').toString('base64'),ext:'txt',mime:'text/plain'};
}
