import { NativeModules } from 'react-native';
export interface ModelState {stage:string;bytes:number;total:number;message:string;progress:number}
export interface Artifact {uri:string;csvUri:string;name:string;mime:string;path:string}
export const Files = NativeModules.AurelioFiles as {
  modelState():Promise<ModelState>; startDownload():Promise<void>;
  selectModel():Promise<void>; openModel():Promise<string>; closeModel():Promise<void>;
  saveDraft(value:string):Promise<void>; readDraft():Promise<string>; clearDraft():Promise<void>;
  publish(name:string,ext:string,mime:string,csv:string,base64:string):Promise<Artifact>;
  pdf(blocks:string):Promise<string>; openDocument(uri:string,mime:string):Promise<void>;
};
