export type Format = 'word' | 'excel' | 'powerpoint' | 'pdf' | 'txt';
export const TOOLS: { id: Format; name: string; ext: string }[] = [
  {id:'word',name:'Word',ext:'docx'}, {id:'excel',name:'Excel',ext:'xlsx'},
  {id:'powerpoint',name:'PowerPoint',ext:'pptx'}, {id:'pdf',name:'PDF',ext:'pdf'},
  {id:'txt',name:'TXT',ext:'txt'},
];
export function norm(s:string) { return s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase(); }
// Detection belongs to this message, never to the preceding menu selection.
export function routeInput(s:string): Format | null {
  const m=s.trimStart().match(/^(word|excel|power\s+point|powerpoint|pdf|txt)(?=$|\s|[:,;.\-])/i);
  return m ? m[1].toLowerCase().replace(/\s/g,'') as Format : null;
}
export interface Plan {
  format:Format; request:string; system:string; summary:string;
  rows?:number; columns?:number; slides?:number;
  constants:{c:number;v:number}[]; random:{c:number;lo:number;hi:number}[];
  products:{c:number;a:number;b:number}[]; total?:number;
}
const numbers=['cero','uno','dos','tres','cuatro','cinco','seis','siete','ocho','nueve','diez','once','doce','trece','catorce','quince','dieciseis','diecisiete','dieciocho','diecinueve','veinte','veintiuno','veintidos','veintitres','veinticuatro','veinticinco','veintiseis','veintisiete','veintiocho','veintinueve','treinta'];
function integer(s:string) { const n=numbers.indexOf(s); return n>=0?n:/^\d+$/.test(s)?Number(s):NaN; }
const num='(?:\\d+|'+[...numbers].sort((a,b)=>b.length-a.length).join('|')+')';
const ords=['primera','segunda','tercera','cuarta','quinta','sexta','septima','octava','novena','decima','undecima','duodecima'];
function col(s:string) { const o=ords.indexOf(s); return o>=0?o:/^\d+$/.test(s)?+s-1:s.charCodeAt(0)-97; }
export function prepare(format:Format,request:string):Plan {
  const q=norm(request), p:Plan={format,request,system:'',summary:'',constants:[],random:[],products:[]};
  if(format==='excel') {
    const count=q.match(new RegExp('('+num+')\\s+(?:nombres|personas|filas|registros|empleados|productos|clientes)\\b'));
    // A request for names along a row is not a request for that many data rows.
    if(count && !/\b(?:primera|una|la)\s+(?:fila|linea)\b/.test(q)) p.rows=integer(count[1]);
    const direct=q.match(new RegExp('('+num+')\\s+columnas\\b'));
    if(direct)p.columns=integer(direct[1]);
    const re=new RegExp('(?:('+ords.join('|')+')\\s+columna|columna\\s+(\\d+|[a-z])\\b)','g');
    const mentions=[...q.matchAll(re)];
    if(mentions.length)p.columns=Math.max(p.columns||0,...mentions.map(m=>col(m[1]||m[2])+1));
    const sections=q.split(/(?=\b(?:en\s+)?(?:la\s+)?(?:primera|segunda|tercera|cuarta|quinta|sexta|septima|octava|novena|decima)\s+columna)/);
    for(const s of sections) {
      const m=s.match(new RegExp('('+ords.join('|')+')\\s+columna'));if(!m)continue;
      const c=col(m[1]);
      const k=s.match(new RegExp('(?:constante|fij[oa])\\s+('+num+')')) || s.match(new RegExp('(?:numero\\s+)?('+num+')\\s+(?:constante|fij[oa])'));
      if(k)p.constants.push({c,v:integer(k[1])});
      if(/azar|aleatori/.test(s)) {
        const r=s.match(new RegExp('(?:del?|entre)\\s+('+num+')\\s+(?:al?|y|hasta)\\s+('+num+')'));
        if(r)p.random.push({c,lo:integer(r[1]),hi:integer(r[2])});
      }
      if(/multiplic|producto/.test(s)) {
        const refs=[...s.slice((m.index||0)+m[0].length).matchAll(re)].map(x=>col(x[1]||x[2]));
        if(refs.length>=2)p.products.push({c,a:refs[0],b:refs[1]});
      }
      if(/sumatoria|suma\b|total/.test(s))p.total=c;
    }
  }
  if(format==='powerpoint') {
    const m=q.match(new RegExp('('+num+')\\s+(?:diapositivas|laminas)\\b'));if(m)p.slides=integer(m[1]);
  }
  const guides:Record<Format,string>={
    excel:'CSV tabular: la primera fila son encabezados, las siguientes datos reales. Usa tantas columnas y filas como exija la orden. Las sumatorias van en una fila final, separada de las filas de datos. Fórmulas Excel A1, funciones en inglés (SUM, AVERAGE, IF), sin separadores de miles. No conviertas nombres en fórmulas. No añadas una columna de índice ni una columna de total si no se pide. Una primera fila explícita del usuario prevalece sobre encabezados convencionales.',
    word:'CSV con exactamente las columnas tipo,contenido. Una fila por bloque. Tipos: titulo, subtitulo, parrafo, vineta, tabla, salto. En tabla, contenido es una matriz JSON de cadenas. Escribe el documento real solicitado, no instrucciones sobre cómo escribirlo. No inventes lugar, fecha, firma ni remitente que no se hayan pedido.',
    pdf:'CSV con exactamente las columnas tipo,contenido. Tipos: titulo, subtitulo, parrafo, vineta, tabla, salto. En tabla, contenido es una matriz JSON. Escribe el contenido real. Conserva acentos y saltos de línea; el agente pagina el documento.',
    txt:'CSV con exactamente las columnas tipo,contenido. Tipos titulo, parrafo, vineta, salto. Escribe el texto real solicitado. El agente guardará contenido UTF-8 sin las etiquetas CSV.',
    powerpoint:'CSV con exactamente las columnas diapositiva,titulo,contenido,notas. Una fila por diapositiva. Numera desde 1. Cada diapositiva contiene un título y contenido real específico; notas son las notas del presentador. Respeta cantidad, tema, orden e idioma solicitados. No escribas instrucciones de diseño en lugar del contenido.',
  };
  const constraints=[p.rows?`${p.rows} filas de datos, sin contar encabezado ni total`:'',p.columns?`${p.columns} columnas`:'',p.slides?`${p.slides} diapositivas`:'',...p.constants.map(x=>`columna ${x.c+1}: constante ${x.v}`),...p.random.map(x=>`columna ${x.c+1}: enteros aleatorios ${x.lo} a ${x.hi}`),...p.products.map(x=>`columna ${x.c+1}: fórmula columna ${x.a+1} por ${x.b+1}`),p.total!==undefined?`sumatoria al pie de columna ${p.total+1}`:''].filter(Boolean).join('; ');
  p.summary=`${TOOLS.find(t=>t.id===format)!.name}${constraints?': '+constraints:''}`;
  p.system=`Eres el modelo generativo de AI_AURELIO. El agente construye y verifica archivos después de tu respuesta. Trabaja en español salvo que la orden solicite otro idioma. Entrega exclusivamente el CSV del documento solicitado, sin Markdown, sin explicaciones del proceso, sin contenido prefabricado. Sintaxis RFC 4180: separador coma; cita campos con comas, comillas o saltos, escapando comillas como "". No recortes contenido solicitado. ${guides[format]} ${constraints?'Requisitos explícitos: '+constraints+'.':''}`;
  return p;
}
export function parseCSV(raw:string):string[][] {
  let text=raw.replace(/^\uFEFF/,'').trim();
  if(text.startsWith('```'))text=text.replace(/^```[^\n]*\n/,'').replace(/\n```\s*$/,'');
  const rows:string[][]=[]; let row:string[]=[], cell='', quoted=false, closed=false;
  for(let i=0;i<text.length;i++) {
    const ch=text[i];
    if(quoted){if(ch==='"'){if(text[i+1]==='"'){cell+='"';i++;}else{quoted=false;closed=true;}}else cell+=ch;continue;}
    if(ch==='"'){if(cell.length||closed)throw Error('Comilla sin escapar dentro de un campo CSV.');quoted=true;continue;}
    if(ch===','||ch==='\n'||ch==='\r') {
      row.push(cell);cell='';closed=false;
      if(ch!==','){if(ch==='\r'&&text[i+1]==='\n')i++;rows.push(row);row=[];}continue;
    }
    if(closed){if(ch===' '||ch==='\t')continue;throw Error('Contenido después del cierre de comillas CSV.');}
    cell+=ch;
  }
  if(quoted)throw Error('El CSV tiene comillas sin cerrar.');
  if(row.length||cell.length||closed){row.push(cell);rows.push(row);}
  if(rows.length<2)throw Error('El CSV necesita estructura y contenido; falta una fila completa.');
  return rows;
}
export function stringifyCSV(rows:string[][]):string {return rows.map(r=>r.map(c=>/[",\r\n]/.test(c)?'"'+c.replace(/"/g,'""')+'"':c).join(',')).join('\r\n');}
export function columnName(i:number):string {let s='';for(i++;i>0;i=Math.floor((i-1)/26))s=String.fromCharCode(65+(i-1)%26)+s;return s;}
function isTotal(row:string[]) {return row.some(c=>/^\s*(?:total(?:\s+general)?|sumatoria|suma)\b/i.test(norm(c))) || row.some(c=>/^\s*=SUM\([A-Z]+\d+:[A-Z]+\d+\)\s*$/i.test(c));}
export function validateAndRepair(raw:string,p:Plan):{rows:string[][];csv:string;repairs:string[]} {
  const rows=parseCSV(raw), repairs:string[]=[];
  if(p.format==='excel') {
    const width=p.columns||rows[0].length;
    if(width>16384)throw Error('La cantidad de columnas excede el formato XLSX.');
    for(let i=0;i<rows.length;i++)if(rows[i].length!==width)throw Error(`Fila ${i+1}: se necesitan ${width} columnas y hay ${rows[i].length}.`);
    const header=rows[0];let data=rows.slice(1);let footer:string[]|undefined;
    if(data.length&&isTotal(data[data.length-1]))footer=data.pop();
    if(p.rows!==undefined&&data.length!==p.rows)throw Error(`Se pidieron ${p.rows} filas de datos y hay ${data.length}; encabezado y sumatoria no cuentan.`);
    if(!data.length)throw Error('La hoja no contiene datos.');
    if(data.length+2>1048576)throw Error('La cantidad de filas excede el formato XLSX.');
    data.forEach((row,i)=>{
      for(const x of p.constants)if(row[x.c]!==String(x.v)){row[x.c]=String(x.v);repairs.push(`Constante corregida en ${columnName(x.c)}${i+2}.`);}
      for(const x of p.random) {
        if(x.lo>x.hi)throw Error('El intervalo aleatorio indicado es inválido.');
        const n=Number(row[x.c]);if(!row[x.c].trim()||!Number.isInteger(n)||n<x.lo||n>x.hi){row[x.c]=String(x.lo+Math.floor(Math.random()*(x.hi-x.lo+1)));repairs.push(`Intervalo corregido en ${columnName(x.c)}${i+2}.`);}
      }
      for(const x of p.products){const f=`=${columnName(x.a)}${i+2}*${columnName(x.b)}${i+2}`;if(row[x.c]!==f){row[x.c]=f;repairs.push(`Fórmula corregida en ${columnName(x.c)}${i+2}.`);}}
    });
    if(p.total!==undefined){footer=Array(width).fill('');if(p.total!==0)footer![0]='TOTAL';footer![p.total]=`=SUM(${columnName(p.total)}2:${columnName(p.total)}${data.length+1})`;repairs.push('Sumatoria verificada al pie de los datos.');}
    rows.splice(0,rows.length,header,...data,...(footer?[footer]:[]));
  } else if(p.format==='powerpoint') {
    if(rows[0].map(norm).join(',')!=='diapositiva,titulo,contenido,notas')throw Error('Encabezado requerido: diapositiva,titulo,contenido,notas.');
    if(p.slides&&rows.length-1!==p.slides)throw Error(`Se pidieron ${p.slides} diapositivas y hay ${rows.length-1}.`);
    rows.slice(1).forEach((r,i)=>{if(r.length!==4||!r[1].trim()||!r[2].trim())throw Error(`Diapositiva ${i+1}: faltan título o contenido.`);r[0]=String(i+1);});
  } else {
    if(rows[0].map(norm).join(',')!=='tipo,contenido')throw Error('Encabezado requerido: tipo,contenido.');
    const types=['titulo','subtitulo','parrafo','vineta','tabla','salto'];
    rows.slice(1).forEach((r,i)=>{if(r.length!==2)throw Error(`Bloque ${i+1}: requiere tipo y contenido.`);r[0]=norm(r[0]);if(!types.includes(r[0]))throw Error(`Tipo de bloque desconocido: ${r[0]}.`);if(r[0]!=='salto'&&!r[1].trim())throw Error(`Bloque ${i+1} vacío.`);if(r[0]==='tabla'){let a;try{a=JSON.parse(r[1]);}catch{throw Error(`Tabla ${i+1}: matriz JSON inválida.`);}if(!Array.isArray(a)||!a.length||!a.every(x=>Array.isArray(x)&&x.length===a[0].length&&x.every(c=>typeof c==='string'||typeof c==='number')))throw Error(`Tabla ${i+1}: filas o celdas inválidas.`);}});
  }
  return {rows,csv:stringifyCSV(rows),repairs};
}
export function preview(rows:string[][],format:Format) {
  if(format==='excel')return rows.map(r=>r.join(' · ')).join('\n');
  if(format==='powerpoint')return rows.slice(1).map(r=>r[0]+'. '+r[1]+'\n'+r[2]).join('\n\n');
  return rows.slice(1).map(r=>r[0]==='salto'?'\n':r[0]==='tabla'?(JSON.parse(r[1]) as unknown[][]).map(x=>x.join(' · ')).join('\n'):r[1]).join('\n\n');
}
// A grammar constrains syntax only; the agent still verifies the user's content.
// Prefix state lets interrupted quoted fields continue without adding a new header.
export function csvGrammar(prefix=''):string {
  let quoted=false, start=true;
  for(let i=0;i<prefix.length;i++){const c=prefix[i];if(quoted){if(c==='"'){if(prefix[i+1]==='"')i++;else quoted=false;}}else if(c==='"'&&start){quoted=true;start=false;}else start=c===','||c==='\n'||c==='\r';}
  return 'root ::= '+(quoted?'qchar* "\\\"" tail':start?'record (nl record)* nl?':'uchar* tail')+'\n'+String.raw`tail ::= ("," field)* (nl record)* nl?
record ::= field ("," field)*
field ::= "\"" qchar* "\"" | uchar*
qchar ::= [^\"] | "\"\""
uchar ::= [^,\r\n\"]
nl ::= "\r\n" | "\n"`;
}
