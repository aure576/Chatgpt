import Runtime from './LlamaRuntimeService';
import { Files } from '../office/native';
export interface ChatMessagePayload {role:'system'|'user'|'assistant';content:string}
class GPTService {
 private static instance:GPTService;
 static getInstance(){return this.instance||(this.instance=new GPTService());}
 async initializeLlamaRuntime(){if(!Runtime.getInstance().ready)await Runtime.getInstance().initializeLlamaRuntime(await Files.openModel());}
 async chatCompletion(messages:string|ChatMessagePayload[],onProgress?:(token:string)=>void){const chat=typeof messages==='string'?[{role:'user',content:messages}]:messages;return Runtime.getInstance().chatCompletion([{role:'system',content:'Responde en español salvo que se pida otro idioma.'},...chat],onProgress);}
 async unloadModel(){await Runtime.getInstance().unloadModel();await Files.closeModel();}
 async stopCompletion(){await Runtime.getInstance().stopCompletion();}
 async downloadModelToMobile(_url:string,_active=true,onProgress?:(p:{bytesWritten:number;totalBytes:number})=>void){await Files.startDownload();for(;;){const s=await Files.modelState();onProgress?.({bytesWritten:s.bytes,totalBytes:s.total});if(s.stage==='downloaded'||s.stage==='ready')return;if(s.stage==='error')throw Error(s.message);await new Promise(r=>setTimeout(r,1500));}}
 async loadModelInfo(){return Files.modelState();}
}
export default GPTService;
