import { initLlama, LlamaContext, loadLlamaModelInfo } from 'llama.rn';
import { csvGrammar, Plan } from '../office/core';
export type Message={role:string;content:string};
class LlamaRuntimeService {
  private static instance:LlamaRuntimeService;
  private context:LlamaContext|null=null;
  private initializing:Promise<void>|null=null;
  private busy=false;
  private cancelled=false;
  public backend='';
  static getInstance(){return this.instance||(this.instance=new LlamaRuntimeService());}
  get ready(){return !!this.context;}
  async initializeLlamaRuntime(model:string,onProgress?:(n:number)=>void) {
    if(this.context)return;if(this.initializing)return this.initializing;
    this.initializing=(async()=>{
      const params={model,use_mmap:true,use_mlock:false,n_ctx:8192,n_batch:256,n_ubatch:128,n_threads:4,cache_type_k:'q8_0' as const,cache_type_v:'q8_0' as const,flash_attn_type:'auto' as const};
      try{this.context=await initLlama({...params,n_gpu_layers:99},onProgress);}catch{this.context=await initLlama({...params,n_gpu_layers:0},onProgress);}
      this.backend=this.context.gpu?'GPU':'CPU';
    })();
    try{await this.initializing;}finally{this.initializing=null;}
  }
  async generate(messages:Message[],onUpdate:(text:string)=>void,plan?:Plan,prefix='',checkpoint?:(s:string)=>Promise<void>):Promise<string> {
    if(!this.context)throw Error('El modelo todavía se está cargando.');
    if(this.busy)throw Error('El modelo está procesando otra solicitud.');
    const ctx=this.context;this.busy=true;this.cancelled=false;let output=prefix;
    try{
      if(plan&&!prefix)await ctx.clearCache(false);
      let history=[...messages];
      let formatted=await ctx.getFormattedChat(history,null,{jinja:true,enable_thinking:false,add_generation_prompt:true});
      let base=formatted.prompt;
      while((await ctx.tokenize(base)).tokens.length>5600&&history.length>2&&!plan){history.splice(1,Math.min(2,history.length-2));formatted=await ctx.getFormattedChat(history,null,{jinja:true,enable_thinking:false,add_generation_prompt:true});base=formatted.prompt;}
      if((await ctx.tokenize(base)).tokens.length>6000)throw Error('La orden supera el contexto disponible; se conserva el borrador para reanudar.');
      let repetitions=0,previous='';
      for(;;){
        if(this.cancelled)throw Error('Trabajo detenido. El borrador está guardado.');
        let tail=output;
        while((await ctx.tokenize(base+tail)).tokens.length>6500&&tail.length>256)tail=tail.slice(Math.floor(tail.length/4));
        const n=(await ctx.tokenize(base+tail)).tokens.length;
        if(n>=7800)throw Error('No queda contexto suficiente; borrador conservado.');
        let chunk='',lastSave=Date.now(),save=Promise.resolve();
        let result;
        try{
          result=await ctx.completion({prompt:base+tail,n_predict:Math.min(2048,8192-n-64),temperature:plan?0.2:0.7,n_threads:4,penalty_repeat:1.1,stop:['<|im_end|>','<|endoftext|>'],...(plan?{grammar:csvGrammar(output)}:{})},d=>{
            chunk=d.accumulated_text||chunk+d.token;onUpdate(output+chunk);
            if(checkpoint&&Date.now()-lastSave>1500){lastSave=Date.now();const snapshot=output+chunk;save=save.then(()=>checkpoint(snapshot));}
          });
        } catch(e){await save;if(checkpoint)await checkpoint(output+chunk);throw e;}
        await save;chunk=result.text||chunk;output+=chunk;onUpdate(output);if(checkpoint)await checkpoint(output);
        if(this.cancelled||result.interrupted)throw Error('Trabajo detenido. El borrador está guardado.');
        if(!result.stopped_limit&&!result.context_full)break;
        if(!chunk.trim()||chunk===previous)repetitions++;else repetitions=0;
        if(repetitions>=2)throw Error('La generación no avanza; borrador conservado para reanudar.');
        previous=chunk;
      }
      if(!output.trim())throw Error('El modelo no produjo contenido.');return output;
    }finally{this.busy=false;}
  }
  async chatCompletion(messages:Message[],onToken?:(s:string)=>void) {let length=0;return this.generate(messages,s=>{onToken?.(s.slice(length));length=s.length;});}
  async stopCompletion(){this.cancelled=true;await this.context?.stopCompletion();}
  async unloadModel(){if(this.busy)throw Error('Detén el trabajo antes de cambiar de modelo.');await this.context?.release();this.context=null;}
  async getModelInfo(path:string){return loadLlamaModelInfo(path);}
}
export default LlamaRuntimeService;
