#!/usr/bin/env python3
"""Build on Linux/macOS/Windows with Node, JDK 21 + 17, and Android SDK installed."""
from pathlib import Path
import hashlib, os, shutil, subprocess, tarfile, urllib.request, secrets
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT)
env=dict(os.environ)
def run(args): subprocess.run([str(x) for x in args],check=True,env=env)
run(['npm','ci','--ignore-scripts','--no-audit','--no-fund'])
archive=ROOT/'node_modules/llama.rn/android-libs.tgz'
url='https://github.com/mybigday/llama.rn/releases/download/v0.12.5/llama-rn-android-jni-libs.tar.gz'
with urllib.request.urlopen(url,timeout=120) as src,archive.open('wb') as out:shutil.copyfileobj(src,out)
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
if sha!='b2ff1c064217e6a1a988e5fe0ffbea2eb063cfc415a323bf9967e16efa36d7a5':raise SystemExit('Bibliotecas nativas: SHA-256 incorrecto.')
with tarfile.open(archive) as z:z.extractall(ROOT/'node_modules/llama.rn',filter='data')
(ROOT/'node_modules/llama.rn/android/src/main/jniLibs/.llama-rn.sha256').write_text(sha)
archive.unlink()
sdk=env.get('ANDROID_HOME') or env.get('ANDROID_SDK_ROOT')
if not sdk:raise SystemExit('Falta ANDROID_HOME con SDK 36, Build Tools 36/35, NDK 27.1.12297006 y CMake 3.22.1.')
(ROOT/'android/local.properties').write_text('sdk.dir='+sdk.replace('\\','/')+'\n')
unsigned=env.get('AI_AURELIO_UNSIGNED')=='1'
keydir=ROOT/'.signing';keydir.mkdir(mode=0o700,exist_ok=True)
key=keydir/'ai-aurelio.jks';password=keydir/'password.txt'
if not unsigned and key.exists() and not password.exists():raise SystemExit('Falta .signing/password.txt de la firma existente.')
if not unsigned and not key.exists():
 password.write_text(secrets.token_urlsafe(32));password.chmod(0o600)
 env['AI_AURELIO_KEY_PASS']=password.read_text().strip()
 run(['keytool','-genkeypair','-noprompt','-keystore',key,'-storetype','JKS','-alias','ai-aurelio','-storepass:env','AI_AURELIO_KEY_PASS','-keypass:env','AI_AURELIO_KEY_PASS','-keyalg','RSA','-keysize','4096','-validity','10000','-dname','CN=AI_AURELIO, O=AI_AURELIO'])
if not unsigned:
 env['AI_AURELIO_KEY_PASS']=password.read_text().strip()
 env['AI_AURELIO_KEYSTORE']=str(key)
env['NODE_ENV']='production'
run(['npx','tsc','--noEmit'])
run(['node','scripts/prueba_minima.cjs'])
os.chdir(ROOT/'android')
wrapper='gradlew.bat' if os.name=='nt' else './gradlew'
if os.name!='nt':Path('gradlew').chmod(0o755)
java_paths=','.join(dict.fromkeys(env[k] for k in ('JAVA_HOME_17_X64','JAVA_HOME_21_X64','JAVA_HOME') if env.get(k)))
java_options=['-Porg.gradle.java.installations.auto-download=false']
if java_paths:java_options.append('-Porg.gradle.java.installations.paths='+java_paths)
run([wrapper,'--no-daemon','--console=plain','--max-workers=2','-PreactNativeArchitectures=arm64-v8a',*java_options,':app:assembleRelease'])
out=ROOT/'dist';out.mkdir(exist_ok=True)
apk_name='app-release-unsigned.apk' if unsigned else 'app-release.apk'
destination='AI_AURELIO-sin-firma.apk' if unsigned else 'AI_AURELIO.apk'
shutil.copy2(ROOT/'android/app/build/outputs/apk/release'/apk_name,out/destination)
print('APK generado:',out/destination)
if unsigned: print('Compilación lista para aplicar la firma privada fuera de CI.')
else: print('Conserva .signing para firmar las futuras actualizaciones.')
