const assert=require('node:assert/strict'),fs=require('node:fs'),Module=require('node:module'),ts=require('typescript');
require.extensions['.ts']=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText,f);
const load=Module._load;Module._load=function(name){if(name==='react-native')return {NativeModules:{AurelioFiles:{}}};return load.apply(this,arguments);};
const core=require('../src/office/core.ts'),{buildDocument}=require('../src/office/exporters.ts'),XLSX=require('xlsx');
(async()=>{
 for(const [text,expected] of [['Word: una carta','word'],['Excel una tabla','excel'],['power point un resumen','powerpoint'],['PowerPoint: resumen','powerpoint'],['PDF informe','pdf'],['TXT nota','txt'],['Explícame cómo funciona Excel',null],['wordplay',null],['Hola',null]])assert.equal(core.routeInput(text),expected);
 const matrix=[['tipo','contenido'],['parrafo','Dijo "hola", y continuó.\nSegunda línea.']];assert.deepEqual(core.parseCSV(core.stringifyCSV(matrix)),matrix);assert.throws(()=>core.parseCSV('tipo,contenido\nparrafo,"sin cierre'));
 const q='Excel en la primera columna crea 16 nombres de personas en la segunda columna la constante 15 en la tercera columna al azar del 7 al 25 en la cuarta columna la multiplicación de la columna 2 por la columna 3 en la cuarta columna la sumatoria de ella misma';
 const p=core.prepare('excel',q);assert.equal(p.rows,16);assert.equal(p.columns,4);assert.equal(p.products.length,1);
 const rows=[['Persona','Constante','Cantidad','Producto'],...Array.from({length:16},(_,i)=>['Prueba '+(i+1),'0','999','0'])];
 const r=core.validateAndRepair(core.stringifyCSV(rows),p);assert.equal(r.rows.length,18);assert.equal(r.rows[1][1],'15');assert.equal(r.rows[1][3],'=B2*C2');assert.equal(r.rows.at(-1)[3],'=SUM(D2:D17)');assert(r.rows.slice(1,-1).every(x=>+x[2]>=7&&+x[2]<=25));
 const x=await buildDocument(r.rows,'excel'),w=XLSX.read(x.base64,{type:'base64',cellFormula:true}),s=w.Sheets.Hoja;assert.equal(s.D2.f,'B2*C2');assert.equal(s.D2.v,15*+r.rows[1][2]);assert.equal(s.D18.v,r.rows.slice(1,-1).reduce((n,x)=>n+15*Number(x[2]),0));
 for(const f of ['word','txt'])assert(Buffer.from((await buildDocument(matrix,f)).base64,'base64').length>10);
 const ppt=await buildDocument([['diapositiva','titulo','contenido','notas'],['1','Prueba','Contenido','']],'powerpoint');assert(Buffer.from(ppt.base64,'base64').subarray(0,2).equals(Buffer.from('PK')));
 console.log('OK: prefijos, CSV, reparación de hoja y generación mínima XLSX/DOCX/PPTX/TXT.');
 console.log('PDF nativo, inferencia y funcionamiento en Android quedan pendientes de prueba en dispositivo.');
})().catch(e=>{console.error(e);process.exitCode=1;});
